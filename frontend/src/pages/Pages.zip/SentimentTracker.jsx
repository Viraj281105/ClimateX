export default function SentimentTracker() {
  return (
    <div className="p-8 text-white">
      <h1 className="text-3xl font-bold">Sentiment Tracker</h1>
      <p className="mt-4">This is a placeholder page for the Sentiment Tracker. Design coming soon!</p>
    </div>
  );
}
